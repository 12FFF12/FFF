﻿#Requires -Version 5.1
<#
  引擎自测脚本 Test-Engine.ps1
  只在本机临时目录内构造沙箱，不触碰真实的缓存目录。
  验证：体积统计 / 安全守卫 / 占用跳过 / 只读删除 / 链接不穿透
#>

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module (Join-Path $here 'CleanerEngine.psm1') -Force

$pass = 0
$fail = 0
function Check {
    param([string]$Name, [bool]$Condition, [string]$Detail = '')
    if ($Condition) {
        $script:pass++
        Write-Host ("  [PASS] " + $Name) -ForegroundColor Green
    } else {
        $script:fail++
        Write-Host ("  [FAIL] " + $Name + "  " + $Detail) -ForegroundColor Red
    }
}

Write-Host "`n=== 1. 模块加载 ===" -ForegroundColor Cyan
Check '模块版本存在' ((Get-CleanerVersion) -ne $null) (Get-CleanerVersion)
Check 'Format-Size 正确' ((Format-Size -Bytes 1536) -eq '2 KB') (Format-Size -Bytes 1536)
Check '安全提示文本非空' ((Get-SafetyNotice).Length -gt 100)

Write-Host "`n=== 2. 安全守卫（必须是拒绝） ===" -ForegroundColor Cyan
$mustReject = @(
    'C:\',
    'C:',
    'C:\Users',
    'C:\Windows',
    'C:\Program Files',
    'C:\Program Files (x86)',
    'C:\ProgramData',
    $env:USERPROFILE,
    (Join-Path $env:USERPROFILE 'Desktop'),
    (Join-Path $env:USERPROFILE 'Documents'),
    (Join-Path $env:USERPROFILE 'Downloads'),
    (Join-Path $env:USERPROFILE 'Pictures'),
    (Join-Path $env:USERPROFILE 'AppData'),
    ''
)
foreach ($p in $mustReject) {
    $g = Test-SafeTarget -Path $p
    Check ("拒绝: " + $(if ($p -eq '') { '<空>' } else { $p })) (-not $g.Safe) ('实际返回 Safe=' + $g.Safe)
}

Write-Host "`n=== 3. 安全守卫（必须是允许） ===" -ForegroundColor Cyan
$mustAllow = @(
    $env:TEMP,
    (Join-Path $env:LOCALAPPDATA 'NVIDIA\DXCache'),
    (Join-Path $env:WINDIR 'Temp'),
    (Join-Path $env:LOCALAPPDATA 'D3DSCache')
)
foreach ($p in $mustAllow) {
    $g = Test-SafeTarget -Path $p
    Check ("允许: " + $p) ($g.Safe) ('拒绝原因=' + $g.Reason)
}

Write-Host "`n=== 4. 沙箱删除测试 ===" -ForegroundColor Cyan
$sandboxRoot = Join-Path $env:TEMP ('CDC_Sandbox_' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
$target = Join-Path $sandboxRoot 'CacheTarget'
$precious = Join-Path $sandboxRoot 'PreciousData'
$locked = Join-Path $target 'locked.log'

New-Item -ItemType Directory -Path $target -Force | Out-Null
New-Item -ItemType Directory -Path $precious -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $target 'sub\deep') -Force | Out-Null

# 普通文件
Set-Content -LiteralPath (Join-Path $target 'a.tmp') -Value ('x' * 1000)
Set-Content -LiteralPath (Join-Path $target 'sub\b.tmp') -Value ('x' * 2000)
Set-Content -LiteralPath (Join-Path $target 'sub\deep\c.tmp') -Value ('x' * 3000)
# 只读文件
Set-Content -LiteralPath (Join-Path $target 'readonly.tmp') -Value ('x' * 500)
Set-ItemProperty -LiteralPath (Join-Path $target 'readonly.tmp') -Name IsReadOnly -Value $true
# 珍贵数据（链接指向这里，绝不能被删）
Set-Content -LiteralPath (Join-Path $precious 'keep-me.txt') -Value 'DO NOT DELETE'
$preciousSizeBefore = (Get-PathSize -LiteralPath $precious).Bytes
# 占用中的文件
Set-Content -LiteralPath $locked -Value ('x' * 700)
$fs = [System.IO.File]::Open($locked, 'Open', 'Read', 'None')

try {
    $size = Get-PathSize -LiteralPath $target
    Check '体积统计 > 0' ($size.Bytes -gt 0) ('Bytes=' + $size.Bytes)
    Check '文件计数正确(>=6)' ($size.Files -eq 5) ('Files=' + $size.Files)

    # 创建目录联接，指向 PreciousData
    $junction = Join-Path $target 'link_to_precious'
    try {
        New-Item -ItemType Junction -Path $junction -Target $precious -ErrorAction Stop | Out-Null
        Check '创建目录联接成功' $true
        $hasJunction = $true
    } catch {
        Check '创建目录联接成功' $false $_.Exception.Message
        $hasJunction = $false
    }

    # 释放沙箱守卫：沙箱在 TEMP 下，应被允许
    $g = Test-SafeTarget -Path $target
    Check '沙箱目标通过守卫' ($g.Safe) $g.Reason

    # 执行清理
    $r = Invoke-CleanPaths -Paths @($target)

    Check '有文件被删除' ($r.DeletedFiles -gt 0) ('DeletedFiles=' + $r.DeletedFiles)
    Check '统计到跳过项' ($r.SkippedCount -ge 1) ('SkippedCount=' + $r.SkippedCount)
    Check '普通文件已删除' (-not (Test-Path -LiteralPath (Join-Path $target 'a.tmp')))
    Check '深层文件已删除' (-not (Test-Path -LiteralPath (Join-Path $target 'sub\deep\c.tmp')))
    Check '只读文件已删除' (-not (Test-Path -LiteralPath (Join-Path $target 'readonly.tmp')))
    Check '占用文件被跳过保留' (Test-Path -LiteralPath $locked)
    Check '目标目录本身保留' (Test-Path -LiteralPath $target)

    if ($hasJunction) {
        Check '联接本身已删除' (-not (Test-Path -LiteralPath $junction))
        $preciousSizeAfter = (Get-PathSize -LiteralPath $precious).Bytes
        Check '链接目标数据未被穿透删除' ($preciousSizeAfter -eq $preciousSizeBefore) ('before=' + $preciousSizeBefore + ' after=' + $preciousSizeAfter)
        Check '珍贵文件仍存在' (Test-Path -LiteralPath (Join-Path $precious 'keep-me.txt'))
    }

    Check '释放字节数 > 0' ($r.FreedBytes -gt 0) ('Freed=' + $r.FreedBytes)
} finally {
    if ($fs) { $fs.Dispose() }
    Remove-Item -LiteralPath $sandboxRoot -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "`n=== 5. 清理项目定义检查 ===" -ForegroundColor Cyan
$cats = @(Resolve-AllCategories)
Check '分类数量 >= 20' ($cats.Count -ge 20) ('实际=' + $cats.Count)
Check '所有分类 Id 唯一' ((($cats | Select-Object -ExpandProperty Id | Select-Object -Unique).Count) -eq $cats.Count)

$badGuard = @()
foreach ($c in $cats) {
    foreach ($p in $c.ResolvedPaths) {
        $g = Test-SafeTarget -Path $p
        if (-not $g.Safe) { $badGuard += ($c.Id + ' -> ' + $p + ' :: ' + $g.Reason) }
    }
}
Check '所有已解析目标均通过守卫' ($badGuard.Count -eq 0) ($badGuard -join '; ')

$undetected = @($cats | Where-Object { $_.ResolvedPaths.Count -eq 0 })
Write-Host ("  提示：本机未检测到的项目 " + $undetected.Count + " 个：" + (($undetected | ForEach-Object { $_.Name }) -join '、')) -ForegroundColor DarkGray

Write-Host "`n=== 6. 体积预估抽样 ===" -ForegroundColor Cyan
foreach ($id in @('UserTemp', 'ThumbnailCache', 'EdgeCache')) {
    $c = $cats | Where-Object { $_.Id -eq $id } | Select-Object -First 1
    if ($c -and $c.ResolvedPaths.Count -gt 0) {
        $est = Get-CategoryEstimate -Category $c
        Check ("预估 " + $c.Name) ($est -ge 0) ([string]$est)
        Write-Host ("    " + $c.Name + " = " + (Format-Size -Bytes ([long]$est))) -ForegroundColor DarkGray
    }
}

Write-Host ("`n========== 结果：通过 " + $pass + " 项，失败 " + $fail + " 项 ==========") -ForegroundColor $(if ($fail -eq 0) { 'Green' } else { 'Red' })
if ($fail -gt 0) { exit 1 }
