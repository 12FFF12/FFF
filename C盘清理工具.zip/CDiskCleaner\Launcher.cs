﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace CDiskCleanerLauncher
{
    /// <summary>
    /// CDiskCleaner 启动器。
    /// 只做一件事：用 PowerShell 打开同目录下的 CDiskCleaner.ps1，
    /// 并且不显示黑色控制台窗口。不修改系统设置、不写注册表、不联网。
    /// </summary>
    internal static class Program
    {
        private const string ScriptName = "CDiskCleaner.ps1";
        private const string EngineName = "CleanerEngine.psm1";

        [STAThread]
        private static int Main(string[] args)
        {
            string baseDir;
            try
            {
                baseDir = AppDomain.CurrentDomain.BaseDirectory;
            }
            catch
            {
                baseDir = Environment.CurrentDirectory;
            }

            string scriptPath = Path.Combine(baseDir, ScriptName);
            string enginePath = Path.Combine(baseDir, EngineName);

            if (!File.Exists(scriptPath))
            {
                ShowError("未找到 " + ScriptName + "。\n\n" +
                          "请确认以下文件都在同一个文件夹里：\n" +
                          "  CDiskCleaner.exe\n" +
                          "  CDiskCleaner.ps1\n" +
                          "  " + EngineName + "\n\n" +
                          "当前查找的位置：\n" + baseDir);
                return 2;
            }

            if (!File.Exists(enginePath))
            {
                ShowError("未找到 " + EngineName + "。\n\n" +
                          "该文件是清理引擎，必须和 " + ScriptName + " 放在一起。\n\n" +
                          "当前查找的位置：\n" + baseDir);
                return 2;
            }

            string powershell = GetPowerShellPath();
            if (powershell == null)
            {
                ShowError("没有找到 Windows PowerShell。\n\n" +
                          "本工具需要 Windows 自带的 PowerShell 5.1，\n" +
                          "通常位于 %SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\。");
                return 3;
            }

            string logPath = Path.Combine(Path.GetTempPath(), "CDiskCleaner_launcher.log");
            var stdout = new StringBuilder();
            var stderr = new StringBuilder();

            var psi = new ProcessStartInfo();
            psi.FileName = powershell;
            psi.Arguments = "-NoProfile -NoLogo -STA -ExecutionPolicy Bypass -File \"" + scriptPath + "\"";
            psi.WorkingDirectory = baseDir;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.StandardErrorEncoding = Encoding.UTF8;

            Process proc;
            try
            {
                proc = Process.Start(psi);
            }
            catch (Exception ex)
            {
                ShowError("启动 PowerShell 失败：\n\n" + ex.Message);
                return 4;
            }

            if (proc == null)
            {
                ShowError("启动 PowerShell 失败（进程未能创建）。");
                return 4;
            }

            proc.OutputDataReceived += delegate(object s, DataReceivedEventArgs e)
            {
                if (e.Data != null) { lock (stdout) { stdout.AppendLine(e.Data); } }
            };
            proc.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e)
            {
                if (e.Data != null) { lock (stderr) { stderr.AppendLine(e.Data); } }
            };
            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();

            proc.WaitForExit();
            int exitCode = proc.ExitCode;

            // 把输出写到日志，方便用户反馈问题
            try
            {
                var sb = new StringBuilder();
                sb.AppendLine("CDiskCleaner launcher log");
                sb.AppendLine("时间: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sb.AppendLine("脚本: " + scriptPath);
                sb.AppendLine("退出码: " + exitCode);
                sb.AppendLine("---- stdout ----");
                lock (stdout) { sb.Append(stdout.ToString()); }
                sb.AppendLine("---- stderr ----");
                lock (stderr) { sb.Append(stderr.ToString()); }
                File.WriteAllText(logPath, sb.ToString(), new UTF8Encoding(true));
            }
            catch
            {
                // 日志写不出来不算错误
            }

            string errText;
            lock (stderr) { errText = stderr.ToString().Trim(); }

            if (exitCode != 0 && errText.Length > 0)
            {
                ShowError("程序异常退出（退出码 " + exitCode + "）。\n\n" +
                          "错误信息：\n" + Truncate(errText, 1200) + "\n\n" +
                          "完整日志：\n" + logPath);
                return exitCode;
            }

            return exitCode;
        }

        private static string GetPowerShellPath()
        {
            string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            if (string.IsNullOrEmpty(win)) { win = Environment.GetEnvironmentVariable("SystemRoot"); }
            if (!string.IsNullOrEmpty(win))
            {
                string p = Path.Combine(win, @"System32\WindowsPowerShell\v1.0\powershell.exe");
                if (File.Exists(p)) { return p; }
            }
            string sys = Environment.SystemDirectory;
            if (!string.IsNullOrEmpty(sys))
            {
                string p2 = Path.Combine(sys, @"WindowsPowerShell\v1.0\powershell.exe");
                if (File.Exists(p2)) { return p2; }
            }
            return null;
        }

        private static string Truncate(string s, int max)
        {
            if (s == null) { return ""; }
            if (s.Length <= max) { return s; }
            return s.Substring(0, max) + "\n...（已截断）";
        }

        private static void ShowError(string message)
        {
            MessageBox.Show(message, "CDiskCleaner — 启动失败",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
