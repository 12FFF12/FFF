﻿#Requires -Version 5.1
<#
================================================================================
 CDiskCleaner 清理引擎 (CleanerEngine.psm1)
================================================================================
 设计原则：安全优先

 1. 白名单制：只有本文件中显式定义的目标才会被清理。引擎不具备"扫描整个
    磁盘然后挑大的删"的能力，因此不存在误删任意目录的可能。
 2. 内容清理：目录类目标只删除目录"内部"的条目，不会删除目录本身。
 3. 个人资料保护：桌面、文档、下载、图片、音乐、视频、OneDrive 等目录，
    以及用户配置目录本身，在 Test-SafeTarget 中被硬性拒绝。
 4. 链接保护：不跟随符号链接/目录联接（Junction），只删除链接本身，
    避免顺着链接删到磁盘其他位置。
 5. 占用跳过：删除过程中被占用的文件会被记录并跳过，不会中断整体流程。
 6. 不格式化：本引擎不含任何格式化、分区、磁盘初始化相关代码。
================================================================================
#>

$script:CleanerVersion = '1.0.0'

# ==============================================================================
# 基础工具
# ==============================================================================

function Get-CleanerVersion {
    <# 返回工具版本号 #>
    return $script:CleanerVersion
}

function Format-Size {
    <# 把字节数转成人类可读字符串 #>
    param([Parameter(Mandatory)][long]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N1} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N0} KB' -f ($Bytes / 1KB)) }
    return ('{0} B' -f $Bytes)
}

function Get-ExtendedPath {
    <#
      给路径加 \\?\ 前缀，突破 260 字符限制。
      .NET 的 IO API 才能正确处理超长路径。
    #>
    param([Parameter(Mandatory)][string]$Path)
    if ($Path.StartsWith('\\?\')) { return $Path }
    if ($Path.StartsWith('\\')) { return '\\?\UNC\' + $Path.Substring(2) }
    return '\\?\' + $Path
}

function Get-FreeSpaceBytes {
    <# 返回系统盘剩余空间（字节） #>
    try {
        $d = New-Object System.IO.DriveInfo ([System.IO.Path]::GetPathRoot($env:SystemDrive))
        return [long]$d.AvailableFreeSpace
    } catch {
        return [long]0
    }
}

function Test-IsAdministrator {
    <# 判断当前进程是否以管理员身份运行 #>
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object Security.Principal.WindowsPrincipal($id)
        return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        return $false
    }
}

# ==============================================================================
# 安全守卫
# ==============================================================================

function Get-ProtectedPaths {
    <#
      返回"绝对不允许被整体清理"的路径集合（小写、去尾斜杠）。
      这些路径既可能是删除目标，也可能是包含个人资料的上级目录。
    #>
    $list = New-Object System.Collections.ArrayList

    # --- 系统关键目录 ---
    $systemCandidates = @(
        $env:WINDIR
        $env:SystemRoot
        $env:ProgramFiles
        ${env:ProgramFiles(x86)}
        $env:ProgramData
        $env:PUBLIC
        $env:SystemDrive
        'C:\Users'
        'C:\Windows'
        'C:\Program Files'
        'C:\Program Files (x86)'
    )
    foreach ($p in $systemCandidates) {
        if (-not [string]::IsNullOrWhiteSpace($p)) { [void]$list.Add($p) }
    }

    # --- 用户个人资料目录（整体禁止） ---
    $personalNames = @(
        'Desktop', 'Documents', 'Downloads', 'Pictures', 'Videos', 'Music',
        'Favorites', 'Links', 'Contacts', 'Saved Games', 'OneDrive',
        'Searches', '3D Objects', 'AppData', '.ssh', '.gnupg', '.config',
        'xwechat_files', 'WeChat Files', 'Tencent Files'
    )
    if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
        [void]$list.Add($env:USERPROFILE)
        foreach ($n in $personalNames) {
            [void]$list.Add((Join-Path $env:USERPROFILE $n))
        }
    }

    $result = New-Object System.Collections.ArrayList
    foreach ($p in $list) {
        try {
            $full = [System.IO.Path]::GetFullPath($p).TrimEnd('\', '/')
            [void]$result.Add($full.ToLowerInvariant())
        } catch { }
    }
    return @($result | Select-Object -Unique)
}

function Test-SafeTarget {
    <#
      核心安全守卫。返回 @{ Safe = $true/$false; Reason = '说明' }
      任何删除动作之前都必须通过这里。
    #>
    param([Parameter(Mandatory)][AllowEmptyString()][string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return @{ Safe = $false; Reason = '路径为空' }
    }

    $full = $null
    try {
        $full = [System.IO.Path]::GetFullPath($Path).TrimEnd('\', '/')
    } catch {
        return @{ Safe = $false; Reason = '路径格式无效' }
    }

    # 1) 拒绝驱动器根目录，例如 C:\ 或 C:
    if ($full -match '^[A-Za-z]:$') {
        return @{ Safe = $false; Reason = '拒绝操作驱动器根目录' }
    }
    # 2) 拒绝过短的绝对路径（如 C:\X），除已显式登记的特殊目标外
    if ($full.Length -le 3) {
        return @{ Safe = $false; Reason = '路径过短，拒绝操作' }
    }

    $cmp = $full.ToLowerInvariant()

    # 3) 精确命中受保护路径
    $protected = Get-ProtectedPaths
    if ($protected -contains $cmp) {
        return @{ Safe = $false; Reason = ('该路径属于受保护目录，拒绝清理: ' + $full) }
    }

    # 4) 目标是否为某个受保护路径的上级（例如目标是 C:\Users）
    foreach ($p in $protected) {
        if ($p.StartsWith($cmp + '\')) {
            return @{ Safe = $false; Reason = ('该目录包含受保护内容，拒绝整体清理: ' + (Split-Path $p -Leaf)) }
        }
    }

    # 5) 目标存在且是链接（符号链接/联接点）时拒绝，防止顺着链接删到别处
    try {
        if ([System.IO.File]::Exists($full) -or [System.IO.Directory]::Exists($full)) {
            $attr = [System.IO.File]::GetAttributes((Get-ExtendedPath $full))
            if ($attr -band [System.IO.FileAttributes]::ReparsePoint) {
                return @{ Safe = $false; Reason = '目标是符号链接或目录联接，已跳过' }
            }
        }
    } catch {
        # 拿不到属性不构成拒绝理由，后续删除时再处理
    }

    return @{ Safe = $true; Reason = '' }
}

# ==============================================================================
# 体积统计
# ==============================================================================

function Get-PathSize {
    <#
      统计目录（或单个文件）的体积。
      - 不跟随符号链接/联接点
      - 无权限的条目直接忽略，不抛异常
      返回 @{ Bytes = [long]; Files = [int] }
    #>
    param([Parameter(Mandatory)][string]$LiteralPath)

    $bytes = [long]0
    $files = 0

    try {
        if ([System.IO.File]::Exists($LiteralPath)) {
            $fi = New-Object System.IO.FileInfo((Get-ExtendedPath $LiteralPath))
            if (-not ($fi.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) {
                $bytes = [long]$fi.Length
                $files = 1
            }
            return [pscustomobject]@{ Bytes = $bytes; Files = $files }
        }
    } catch { }

    $stack = New-Object System.Collections.Stack
    $stack.Push((Get-ExtendedPath $LiteralPath))

    while ($stack.Count -gt 0) {
        $current = $stack.Pop()
        $entries = $null
        try {
            $entries = [System.IO.Directory]::EnumerateFileSystemEntries($current)
        } catch {
            continue
        }
        try {
            foreach ($entry in $entries) {
                try {
                    $attr = [System.IO.File]::GetAttributes($entry)
                    if ($attr -band [System.IO.FileAttributes]::ReparsePoint) { continue }
                    if ($attr -band [System.IO.FileAttributes]::Directory) {
                        $stack.Push($entry)
                    } else {
                        $bytes += [long]([System.IO.FileInfo]$entry).Length
                        $files++
                    }
                } catch { }
            }
        } catch { }
    }

    return [pscustomobject]@{ Bytes = $bytes; Files = $files }
}

# ==============================================================================
# 安全删除
# ==============================================================================

function Clear-PathTree {
    <#
      安全递归删除。规则：
        - 遇到链接（ReparsePoint）只删链接本身，绝不进入
        - 只读属性会自动清除后重试
        - 被占用/无权限的条目记录到 $Skipped 后继续
      返回更新后的统计哈希。
    #>
    param(
        [Parameter(Mandatory)][string]$LiteralPath,
        [Parameter(Mandatory)][hashtable]$Stats,
        [Parameter(Mandatory)][AllowEmptyCollection()][System.Collections.ArrayList]$Skipped,
        [Parameter(Mandatory)][AllowEmptyCollection()][System.Collections.ArrayList]$Denied,
        [int]$Depth = 0
    )

    $ext = Get-ExtendedPath $LiteralPath

    if ($Depth -gt 64) {
        $Stats.SkippedCount++
        [void]$Skipped.Add([pscustomobject]@{ Path = $LiteralPath; Reason = '目录层级过深，已跳过' })
        return $Stats
    }

    # --- 读取属性 ---
    $attr = $null
    try {
        $attr = [System.IO.File]::GetAttributes($ext)
    } catch [System.UnauthorizedAccessException] {
        $Stats.SkippedCount++
        [void]$Denied.Add([pscustomobject]@{ Path = $LiteralPath; Reason = '无访问权限' })
        return $Stats
    } catch [System.IO.FileNotFoundException] {
        return $Stats
    } catch [System.IO.DirectoryNotFoundException] {
        return $Stats
    } catch {
        $Stats.SkippedCount++
        [void]$Skipped.Add([pscustomobject]@{ Path = $LiteralPath; Reason = $_.Exception.Message })
        return $Stats
    }

    $isDir = [bool]($attr -band [System.IO.FileAttributes]::Directory)

    # --- 链接：只删链接自身 ---
    if ($attr -band [System.IO.FileAttributes]::ReparsePoint) {
        try {
            if ($isDir) { [System.IO.Directory]::Delete($ext, $false) }
            else { [System.IO.File]::Delete($ext) }
            $Stats.DeletedEntries++
        } catch {
            $Stats.SkippedCount++
            [void]$Skipped.Add([pscustomobject]@{ Path = $LiteralPath; Reason = '链接删除失败' })
        }
        return $Stats
    }

    # --- 文件 ---
    if (-not $isDir) {
        $len = [long]0
        try { $len = [long]([System.IO.FileInfo]$ext).Length } catch { }
        try {
            [System.IO.File]::Delete($ext)
            $Stats.DeletedFiles++
            $Stats.FreedBytes += $len
        } catch [System.UnauthorizedAccessException] {
            # 只读文件：清除属性后重试一次
            $retried = $false
            try {
                [System.IO.File]::SetAttributes($ext, [System.IO.FileAttributes]::Normal)
                [System.IO.File]::Delete($ext)
                $Stats.DeletedFiles++
                $Stats.FreedBytes += $len
                $retried = $true
            } catch { }
            if (-not $retried) {
                $Stats.SkippedCount++
                [void]$Denied.Add([pscustomobject]@{ Path = $LiteralPath; Reason = '无权限删除（可能被占用或受保护）' })
            }
        } catch [System.IO.IOException] {
            $Stats.SkippedCount++
            [void]$Skipped.Add([pscustomobject]@{ Path = $LiteralPath; Reason = '文件被占用' })
        } catch {
            $Stats.SkippedCount++
            [void]$Skipped.Add([pscustomobject]@{ Path = $LiteralPath; Reason = $_.Exception.Message })
        }
        return $Stats
    }

    # --- 目录：先清空子项，再删自身 ---
    $children = $null
    try {
        $children = @([System.IO.Directory]::EnumerateFileSystemEntries($ext))
    } catch [System.UnauthorizedAccessException] {
        $Stats.SkippedCount++
        [void]$Denied.Add([pscustomobject]@{ Path = $LiteralPath; Reason = '无访问权限' })
        return $Stats
    } catch {
        $Stats.SkippedCount++
        [void]$Skipped.Add([pscustomobject]@{ Path = $LiteralPath; Reason = $_.Exception.Message })
        return $Stats
    }

    foreach ($child in $children) {
        $Stats = Clear-PathTree -LiteralPath $child -Stats $Stats -Skipped $Skipped -Denied $Denied -Depth ($Depth + 1)
    }

    # 只有当子项全部清空时才删除目录本身
    try {
        [System.IO.Directory]::Delete($ext, $false)
        $Stats.DeletedDirs++
    } catch {
        # 目录非空（有跳过的文件）或权限不足，保留目录即可
    }

    return $Stats
}

function Invoke-CleanPaths {
    <#
      对一组路径执行清理：
        - 目录：删除目录内部所有内容，保留目录本身
        - 文件：直接删除
      返回 @{ FreedBytes; DeletedFiles; DeletedDirs; SkippedCount; Denied; Skipped; Errors }
    #>
    param(
        [Parameter(Mandatory)][string[]]$Paths,
        [scriptblock]$OnPath = $null
    )

    $stats = @{
        FreedBytes   = [long]0
        DeletedFiles = 0
        DeletedDirs  = 0
        DeletedEntries = 0
        SkippedCount = 0
    }
    $skipped = New-Object System.Collections.ArrayList
    $denied = New-Object System.Collections.ArrayList
    $errors = New-Object System.Collections.ArrayList

    foreach ($p in $Paths) {
        $guard = Test-SafeTarget -Path $p
        if (-not $guard.Safe) {
            [void]$errors.Add([pscustomobject]@{ Path = $p; Reason = $guard.Reason })
            continue
        }

        if ($null -ne $OnPath) {
            try { & $OnPath $p } catch { }
        }

        # 目标本身是文件（通配符匹配出来的缓存文件）
        if ([System.IO.File]::Exists($p)) {
            $stats = Clear-PathTree -LiteralPath $p -Stats $stats -Skipped $skipped -Denied $denied
            continue
        }

        if (-not [System.IO.Directory]::Exists($p)) { continue }

        $children = $null
        try {
            $children = @([System.IO.Directory]::EnumerateFileSystemEntries((Get-ExtendedPath $p)))
        } catch [System.UnauthorizedAccessException] {
            [void]$denied.Add([pscustomobject]@{ Path = $p; Reason = '无访问权限' })
            continue
        } catch {
            [void]$skipped.Add([pscustomobject]@{ Path = $p; Reason = $_.Exception.Message })
            continue
        }

        foreach ($child in $children) {
            $stats = Clear-PathTree -LiteralPath $child -Stats $stats -Skipped $skipped -Denied $denied
        }
    }

    return [pscustomobject]@{
        FreedBytes   = [long]$stats.FreedBytes
        DeletedFiles = $stats.DeletedFiles
        DeletedDirs  = $stats.DeletedDirs
        DeletedEntries = $stats.DeletedEntries
        SkippedCount = $stats.SkippedCount
        Denied       = @($denied)
        Skipped      = @($skipped)
        Errors       = @($errors)
    }
}

# ==============================================================================
# 清理项目定义（白名单）
# ==============================================================================

function New-CleanCategory {
    param(
        [Parameter(Mandatory)][string]$Id,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Group,
        [Parameter(Mandatory)][ValidateSet('Safe', 'Caution', 'High')][string]$Risk,
        [bool]$Admin = $false,
        [string]$Description = '',
        [string[]]$Paths = @(),
        [string]$Action = '',
        [string]$ActionDetail = ''
    )
    return [pscustomobject]@{
        Id            = $Id
        Name          = $Name
        Group         = $Group
        Risk          = $Risk
        Admin         = $Admin
        Description   = $Description
        Paths         = @($Paths)
        Action        = $Action
        ActionDetail  = $ActionDetail
        ResolvedPaths = @()
    }
}

function Get-CleanCategories {
    <#
      返回全部清理项目定义。
      注意：这里每一个路径都是固化的白名单，引擎不会自行发明目标。
    #>
    $defs = @(
        # ---------------- 临时文件 ----------------
        @{
            Id = 'UserTemp'; Name = '用户临时文件'; Group = '临时文件'; Risk = 'Safe'; Admin = $false
            Description = '当前用户的临时目录，软件运行时产生的中间文件。删除后系统会自动重建。'
            Paths = @('%TEMP%')
        },
        @{
            Id = 'WindowsTemp'; Name = '系统临时文件'; Group = '临时文件'; Risk = 'Safe'; Admin = $true
            Description = 'Windows 系统临时目录，安装程序与系统服务留下的中间文件。'
            Paths = @('%WINDIR%\Temp')
        },
        @{
            Id = 'ThumbnailCache'; Name = '缩略图与图标缓存'; Group = '临时文件'; Risk = 'Safe'; Admin = $false
            Description = '资源管理器生成的缩略图数据库。删除后首次打开文件夹会稍慢，随后自动重建。'
            Paths = @(
                '%LOCALAPPDATA%\Microsoft\Windows\Explorer\thumbcache_*.db',
                '%LOCALAPPDATA%\Microsoft\Windows\Explorer\iconcache_*.db',
                '%LOCALAPPDATA%\Microsoft\Windows\Caches\*.db'
            )
        },
        @{
            Id = 'WindowsLogs'; Name = 'Windows 日志与小型转储'; Group = '临时文件'; Risk = 'Safe'; Admin = $true
            Description = '系统日志、内核转储、蓝屏小型转储文件。用于排查问题，日常可清理。'
            Paths = @(
                '%WINDIR%\Logs',
                '%WINDIR%\Minidump',
                '%WINDIR%\LiveKernelReports'
            )
        },
        @{
            Id = 'Prefetch'; Name = '预读取数据'; Group = '临时文件'; Risk = 'Caution'; Admin = $true
            Description = 'Windows 预读取缓存，可加快程序启动。删除后前几次启动会略慢，之后自动恢复。'
            Paths = @('%WINDIR%\Prefetch')
        },

        # ---------------- 浏览器 ----------------
        @{
            Id = 'EdgeCache'; Name = 'Microsoft Edge 缓存'; Group = '浏览器'; Risk = 'Safe'; Admin = $false
            Description = '网页缓存、代码缓存、GPU 缓存与着色器缓存。不影响书签、密码与登录状态。'
            Paths = @(
                '%LOCALAPPDATA%\Microsoft\Edge\User Data\*\Cache',
                '%LOCALAPPDATA%\Microsoft\Edge\User Data\*\Code Cache',
                '%LOCALAPPDATA%\Microsoft\Edge\User Data\*\GPUCache',
                '%LOCALAPPDATA%\Microsoft\Edge\User Data\*\Service Worker\CacheStorage',
                '%LOCALAPPDATA%\Microsoft\Edge\User Data\GrShaderCache',
                '%LOCALAPPDATA%\Microsoft\Edge\User Data\ShaderCache',
                '%LOCALAPPDATA%\Microsoft\Edge\User Data\DawnCache'
            )
        },
        @{
            Id = 'ChromeCache'; Name = 'Google Chrome 缓存'; Group = '浏览器'; Risk = 'Safe'; Admin = $false
            Description = '网页缓存、代码缓存、GPU 缓存与着色器缓存。不影响书签、密码与登录状态。'
            Paths = @(
                '%LOCALAPPDATA%\Google\Chrome\User Data\*\Cache',
                '%LOCALAPPDATA%\Google\Chrome\User Data\*\Code Cache',
                '%LOCALAPPDATA%\Google\Chrome\User Data\*\GPUCache',
                '%LOCALAPPDATA%\Google\Chrome\User Data\*\Service Worker\CacheStorage',
                '%LOCALAPPDATA%\Google\Chrome\User Data\GrShaderCache',
                '%LOCALAPPDATA%\Google\Chrome\User Data\ShaderCache'
            )
        },
        @{
            Id = 'FirefoxCache'; Name = 'Mozilla Firefox 缓存'; Group = '浏览器'; Risk = 'Safe'; Admin = $false
            Description = 'Firefox 的网页缓存与启动缓存。不影响书签、密码与登录状态。'
            Paths = @(
                '%LOCALAPPDATA%\Mozilla\Firefox\Profiles\*\cache2',
                '%LOCALAPPDATA%\Mozilla\Firefox\Profiles\*\startupCache',
                '%LOCALAPPDATA%\Mozilla\Firefox\Profiles\*\OfflineCache'
            )
        },
        @{
            Id = 'OtherBrowserCache'; Name = '其他浏览器缓存'; Group = '浏览器'; Risk = 'Safe'; Admin = $false
            Description = '360、QQ、搜狗、Opera、Brave、Vivaldi、Yandex 等浏览器的网页缓存（存在才清理）。'
            Paths = @(
                '%LOCALAPPDATA%\360Chrome\Chrome\User Data\*\Cache',
                '%LOCALAPPDATA%\360ChromeX\Chrome\User Data\*\Cache',
                '%LOCALAPPDATA%\Tencent\QQBrowser\User Data\*\Cache',
                '%LOCALAPPDATA%\SogouExplorer\Webkit\Default\Cache',
                '%APPDATA%\Opera Software\Opera Stable\Cache',
                '%APPDATA%\Opera Software\Opera Stable\Code Cache',
                '%LOCALAPPDATA%\BraveSoftware\Brave-Browser\User Data\*\Cache',
                '%LOCALAPPDATA%\Vivaldi\User Data\*\Cache',
                '%LOCALAPPDATA%\Yandex\YandexBrowser\User Data\*\Cache'
            )
        },

        # ---------------- 显卡 / 图形 ----------------
        @{
            Id = 'NvidiaCache'; Name = 'NVIDIA 图形缓存'; Group = '显卡缓存'; Risk = 'Safe'; Admin = $true
            Description = 'DirectX/OpenGL 着色器缓存，以及 NVIDIA App 下载的驱动更新包。游戏首次进入会重新生成，可能略有卡顿。'
            Paths = @(
                '%LOCALAPPDATA%\NVIDIA\DXCache',
                '%LOCALAPPDATA%\NVIDIA\GLCache',
                '%LOCALAPPDATA%\NVIDIA Corporation\NV_Cache',
                '%ProgramData%\NVIDIA Corporation\NVIDIA App\UpdateFramework\ota-artifacts'
            )
        },
        @{
            Id = 'GraphicsCache'; Name = 'DirectX / AMD / Intel 图形缓存'; Group = '显卡缓存'; Risk = 'Safe'; Admin = $false
            Description = 'DirectX 着色器缓存以及 AMD、Intel 显卡的着色器缓存，可自动重建。'
            Paths = @(
                '%LOCALAPPDATA%\D3DSCache',
                '%LOCALAPPDATA%\AMD\DxCache',
                '%LOCALAPPDATA%\AMD\DxcCache',
                '%LOCALAPPDATA%\AMD\GLCache',
                '%LOCALAPPDATA%\Intel\ShaderCache'
            )
        },

        # ---------------- 系统 ----------------
        @{
            Id = 'WindowsUpdate'; Name = 'Windows 更新缓存'; Group = '系统'; Risk = 'Safe'; Admin = $true
            Description = '已下载的系统更新安装包。清理后不影响已安装的更新，仅后续更新需要重新下载。'
            Paths = @('%WINDIR%\SoftwareDistribution\Download')
        },
        @{
            Id = 'DeliveryOptimization'; Name = '传递优化缓存'; Group = '系统'; Risk = 'Safe'; Admin = $true
            Description = 'Windows 更新点对点分发缓存，用于局域网内共享更新包。'
            Paths = @(
                '%WINDIR%\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization',
                '%ProgramData%\Microsoft\Windows\DeliveryOptimization\Cache'
            )
        },
        @{
            Id = 'ErrorReports'; Name = '错误报告与崩溃转储'; Group = '系统'; Risk = 'Safe'; Admin = $true
            Description = '程序崩溃时生成的转储文件与 Windows 错误报告队列。'
            Paths = @(
                '%LOCALAPPDATA%\CrashDumps',
                '%LOCALAPPDATA%\Microsoft\Windows\WER',
                '%ProgramData%\Microsoft\Windows\WER\ReportQueue',
                '%ProgramData%\Microsoft\Windows\WER\ReportArchive'
            )
        },
        @{
            Id = 'RecycleBin'; Name = '回收站'; Group = '系统'; Risk = 'Caution'; Admin = $false
            Description = '清空当前用户的回收站。注意：清空后其中的文件将无法恢复，请先确认没有需要找回的内容。'
            Action = 'RecycleBin'; ActionDetail = '清空当前用户回收站'
        },
        @{
            Id = 'WindowsOld'; Name = '旧版 Windows 安装文件'; Group = '系统'; Risk = 'Caution'; Admin = $true
            Description = '系统升级后保留的旧版本文件（Windows.old 等）。删除后将无法回滚到旧系统。'
            Paths = @(
                '%SystemDrive%\Windows.old',
                '%SystemDrive%\$Windows.~BT',
                '%SystemDrive%\$Windows.~WS',
                '%SystemDrive%\ESD'
            )
        },
        @{
            Id = 'ComponentStore'; Name = '组件存储清理 (WinSxS)'; Group = '系统'; Risk = 'Caution'; Admin = $true
            Description = '通过系统自带的 DISM 清理 WinSxS 中被取代的组件版本。不删除任何用户数据。'
            Action = 'ComponentStore'; ActionDetail = 'DISM /StartComponentCleanup'
        },
        @{
            Id = 'ComponentStoreReset'; Name = '组件存储深度清理 (含 ResetBase)'; Group = '系统'; Risk = 'High'; Admin = $true
            Description = '在组件清理基础上额外执行 ResetBase。清理更彻底，但之后无法卸载已安装的 Windows 更新。'
            Action = 'ComponentStoreReset'; ActionDetail = 'DISM /StartComponentCleanup /ResetBase'
        },
        @{
            Id = 'HibernateOff'; Name = '关闭休眠并删除 hiberfil.sys'; Group = '系统'; Risk = 'High'; Admin = $true
            Description = '关闭系统休眠功能，释放与内存等大的 hiberfil.sys 文件。副作用：将同时关闭「快速启动」，开机会慢几秒。'
            Action = 'HibernateOff'; ActionDetail = 'powercfg /hibernate off'
        },

        # ---------------- 应用缓存 ----------------
        @{
            Id = 'VSCodeCache'; Name = 'VS Code 缓存'; Group = '应用缓存'; Risk = 'Safe'; Admin = $false
            Description = 'Visual Studio Code 的缓存、日志与 GPU 缓存。不影响设置、插件与代码。'
            Paths = @(
                '%APPDATA%\Code\Cache',
                '%APPDATA%\Code\CachedData',
                '%APPDATA%\Code\GPUCache',
                '%APPDATA%\Code\logs',
                '%APPDATA%\Code\Service Worker\CacheStorage',
                '%APPDATA%\Code\CachedExtensionVSIXs'
            )
        },
        @{
            Id = 'AdobeCache'; Name = 'Adobe 媒体缓存'; Group = '应用缓存'; Risk = 'Safe'; Admin = $false
            Description = 'Premiere / After Effects 等软件生成的媒体缓存与峰值文件，可自动重建。'
            Paths = @(
                '%APPDATA%\Adobe\Common\Media Cache',
                '%APPDATA%\Adobe\Common\Media Cache Files',
                '%LOCALAPPDATA%\Adobe\Common\Media Cache Files'
            )
        },
        @{
            Id = 'OfficeCache'; Name = 'Microsoft Office 缓存'; Group = '应用缓存'; Risk = 'Safe'; Admin = $false
            Description = 'Office 文档在本地的临时缓存，不影响已保存的文件。'
            Paths = @(
                '%LOCALAPPDATA%\Microsoft\Office\16.0\OfficeFileCache',
                '%LOCALAPPDATA%\Microsoft\Office\15.0\OfficeFileCache'
            )
        },
        @{
            Id = 'ChatAppCache'; Name = '通讯与会议软件缓存'; Group = '应用缓存'; Risk = 'Safe'; Admin = $false
            Description = 'Teams、Discord、Slack、Spotify 的网页缓存。不删除聊天记录、登录状态或下载的文件。'
            Paths = @(
                '%APPDATA%\Microsoft\Teams\Cache',
                '%APPDATA%\Microsoft\Teams\Code Cache',
                '%APPDATA%\Microsoft\Teams\GPUCache',
                '%APPDATA%\Microsoft\Teams\Service Worker\CacheStorage',
                '%APPDATA%\discord\Cache',
                '%APPDATA%\discord\Code Cache',
                '%APPDATA%\discord\GPUCache',
                '%APPDATA%\discord\Service Worker\CacheStorage',
                '%APPDATA%\Slack\Cache',
                '%APPDATA%\Slack\Code Cache',
                '%APPDATA%\Slack\GPUCache',
                '%LOCALAPPDATA%\Spotify\Storage'
            )
        },

        # ---------------- 开发缓存 ----------------
        @{
            Id = 'NpmCache'; Name = 'npm / yarn 缓存'; Group = '开发缓存'; Risk = 'Safe'; Admin = $false
            Description = 'Node.js 包管理器下载缓存。删除后下次安装依赖需要重新联网下载。'
            Paths = @(
                '%LOCALAPPDATA%\npm-cache',
                '%LOCALAPPDATA%\Yarn\Cache'
            )
        },
        @{
            Id = 'PnpmStore'; Name = 'pnpm 全局存储'; Group = '开发缓存'; Risk = 'Caution'; Admin = $false
            Description = 'pnpm 的内容寻址存储。已安装项目的 node_modules 通常不受影响，但重新安装依赖需要重新下载。'
            Paths = @('%LOCALAPPDATA%\pnpm\store')
        },
        @{
            Id = 'PipCache'; Name = 'pip / uv 缓存'; Group = '开发缓存'; Risk = 'Safe'; Admin = $false
            Description = 'Python 包管理器下载缓存，可安全删除。'
            Paths = @(
                '%LOCALAPPDATA%\pip\Cache',
                '%LOCALAPPDATA%\uv\cache'
            )
        },
        @{
            Id = 'GoBuildCache'; Name = 'Go 构建缓存'; Group = '开发缓存'; Risk = 'Safe'; Admin = $false
            Description = 'Go 编译缓存，删除后重新编译会慢一些。'
            Paths = @('%LOCALAPPDATA%\go-build')
        },
        @{
            Id = 'NuGetCache'; Name = 'NuGet 包缓存'; Group = '开发缓存'; Risk = 'Caution'; Admin = $false
            Description = '.NET 项目依赖包缓存。删除后离线环境将无法还原项目依赖，需要联网重新下载。'
            Paths = @('%USERPROFILE%\.nuget\packages')
        },
        @{
            Id = 'GradleMavenCache'; Name = 'Gradle / Maven 缓存'; Group = '开发缓存'; Risk = 'Caution'; Admin = $false
            Description = 'Java 构建工具的依赖缓存。删除后项目构建需要重新联网下载依赖。'
            Paths = @(
                '%USERPROFILE%\.gradle\caches',
                '%USERPROFILE%\.m2\repository'
            )
        }
    )

    $categories = New-Object System.Collections.ArrayList
    foreach ($d in $defs) {
        [void]$categories.Add((New-CleanCategory @d))
    }
    return @($categories)
}

# ==============================================================================
# 目标解析
# ==============================================================================

function Resolve-CleanCategory {
    <#
      把 %环境变量% 与通配符展开成真实路径，只保留实际存在的目标。
      返回一个新的分类对象（不修改入参）。
    #>
    param([Parameter(Mandatory)]$Category)

    $resolved = New-Object System.Collections.ArrayList
    $missing = New-Object System.Collections.ArrayList

    foreach ($raw in $Category.Paths) {
        $expanded = $null
        try { $expanded = [Environment]::ExpandEnvironmentVariables($raw) } catch { continue }
        if ([string]::IsNullOrWhiteSpace($expanded) -or $expanded -match '%\w+%') { continue }

        if ($expanded -match '[*?]') {
            $matches = @()
            try { $matches = @(Get-Item -Path $expanded -Force -ErrorAction SilentlyContinue) } catch { }
            foreach ($m in $matches) {
                if ($null -ne $m -and $m.FullName) { [void]$resolved.Add($m.FullName) }
            }
        } else {
            if ([System.IO.Directory]::Exists($expanded) -or [System.IO.File]::Exists($expanded)) {
                [void]$resolved.Add($expanded)
            } else {
                [void]$missing.Add($expanded)
            }
        }
    }

    $unique = @($resolved | Select-Object -Unique)

    $clone = $Category.PSObject.Copy()
    $clone.ResolvedPaths = $unique
    return $clone
}

function Resolve-AllCategories {
    <# 解析全部清理项目，返回带 ResolvedPaths 的分类列表 #>
    $categories = Get-CleanCategories
    $output = New-Object System.Collections.ArrayList
    foreach ($c in $categories) {
        [void]$output.Add((Resolve-CleanCategory -Category $c))
    }
    return @($output)
}

# ==============================================================================
# 体积预估
# ==============================================================================

function Get-CategoryEstimate {
    <#
      预估某个分类可释放的体积。
      自定义动作用特殊方式估算；无法估算时返回 -1 表示"运行时才能确定"。
    #>
    param([Parameter(Mandatory)]$Category)

    switch ($Category.Action) {
        'RecycleBin' {
            $total = [long]0
            try {
                $rb = Join-Path $env:SystemDrive '$Recycle.Bin'
                if ([System.IO.Directory]::Exists($rb)) {
                    $total = (Get-PathSize -LiteralPath $rb).Bytes
                }
            } catch { }
            return $total
        }
        'HibernateOff' {
            try {
                $hf = Join-Path $env:SystemDrive 'hiberfil.sys'
                if ([System.IO.File]::Exists($hf)) { return [long]([System.IO.FileInfo]$hf).Length }
            } catch { }
            return [long]0
        }
        'ComponentStore' { return [long]-1 }
        'ComponentStoreReset' { return [long]-1 }
    }

    $totalBytes = [long]0
    $totalFiles = 0
    foreach ($p in $Category.ResolvedPaths) {
        $guard = Test-SafeTarget -Path $p
        if (-not $guard.Safe) { continue }
        $r = Get-PathSize -LiteralPath $p
        $totalBytes += $r.Bytes
        $totalFiles += $r.Files
    }
    return [long]$totalBytes
}

# ==============================================================================
# 执行清理
# ==============================================================================

function Invoke-CleanCategory {
    <#
      执行单个清理项目。
      返回 @{ Id; Name; FreedBytes; ... ; Success; Message }
    #>
    param(
        [Parameter(Mandatory)]$Category,
        [scriptblock]$OnPath = $null
    )

    $freeBefore = Get-FreeSpaceBytes

    if (-not [string]::IsNullOrWhiteSpace($Category.Action)) {
        $result = Invoke-CleanAction -Category $Category
        if ($null -ne $result) { return $result }
    }

    $paths = @($Category.ResolvedPaths)
    if ($paths.Count -eq 0) {
        return [pscustomobject]@{
            Id = $Category.Id; Name = $Category.Name; Risk = $Category.Risk
            Success = $false; FreedBytes = [long]0
            DeletedFiles = 0; DeletedDirs = 0; SkippedCount = 0
            Denied = @(); Skipped = @(); Errors = @()
            Message = '没有可清理的路径'
        }
    }

    $r = Invoke-CleanPaths -Paths $paths -OnPath $OnPath
    if ($null -eq $r) {
        return [pscustomobject]@{
            Id = $Category.Id; Name = $Category.Name; Risk = $Category.Risk
            Success = $false; FreedBytes = [long]0
            DeletedFiles = 0; DeletedDirs = 0; SkippedCount = 0
            Denied = @(); Skipped = @(); Errors = @()
            Message = '清理过程未返回结果'
        }
    }
    $freeAfter = Get-FreeSpaceBytes

    $freed = $r.FreedBytes
    # 以磁盘实际变化做校验：取两者中较大者，但不超过实际可用空间增量太多时以文件统计为准
    if ($freeAfter -gt $freeBefore) {
        $delta = $freeAfter - $freeBefore
        if ($delta -gt $freed) { $freed = $delta }
    }

    $message = ''
    if ($r.Denied.Count -gt 0) {
        $message = ('{0} 项因权限不足被跳过' -f $r.Denied.Count)
    }

    return [pscustomobject]@{
        Id           = $Category.Id
        Name         = $Category.Name
        Risk         = $Category.Risk
        Success      = $true
        FreedBytes   = [long]$freed
        DeletedFiles = $r.DeletedFiles
        DeletedDirs  = $r.DeletedDirs
        SkippedCount = $r.SkippedCount
        Denied       = $r.Denied
        Skipped      = $r.Skipped
        Errors       = $r.Errors
        Message      = $message
    }
}

function Invoke-CleanAction {
    <# 执行需要特殊处理的清理动作 #>
    param([Parameter(Mandatory)]$Category)

    $freeBefore = Get-FreeSpaceBytes
    $isAdmin = Test-IsAdministrator

    switch ($Category.Action) {

        'RecycleBin' {
            $msg = ''
            try {
                Clear-RecycleBin -Force -ErrorAction Stop
                $msg = '回收站已清空'
            } catch {
                $msg = '回收站清空失败：' + $_.Exception.Message
            }
            Start-Sleep -Milliseconds 300
            $freeAfter = Get-FreeSpaceBytes
            $freed = [long]0
            if ($freeAfter -gt $freeBefore) { $freed = $freeAfter - $freeBefore }
            return [pscustomobject]@{
                Id = $Category.Id; Name = $Category.Name; Risk = $Category.Risk
                Success = ($msg -eq '回收站已清空'); FreedBytes = $freed
                DeletedFiles = 0; DeletedDirs = 0; SkippedCount = 0
                Denied = @(); Skipped = @(); Errors = @(); Message = $msg
            }
        }

        'HibernateOff' {
            if (-not $isAdmin) {
                return (New-ActionFailure -Category $Category -Message '需要管理员权限才能关闭休眠')
            }
            $hf = Join-Path $env:SystemDrive 'hiberfil.sys'
            $sizeBefore = [long]0
            try { if ([System.IO.File]::Exists($hf)) { $sizeBefore = [long]([System.IO.FileInfo]$hf).Length } } catch { }

            $out = & powercfg.exe /hibernate off 2>&1
            Start-Sleep -Milliseconds 500
            $freeAfter = Get-FreeSpaceBytes
            $exists = $false
            try { $exists = [System.IO.File]::Exists($hf) } catch { }

            if (-not $exists) {
                return [pscustomobject]@{
                    Id = $Category.Id; Name = $Category.Name; Risk = $Category.Risk
                    Success = $true; FreedBytes = $sizeBefore
                    DeletedFiles = 0; DeletedDirs = 0; SkippedCount = 0
                    Denied = @(); Skipped = @(); Errors = @()
                    Message = '休眠已关闭，hiberfil.sys 已释放'
                }
            }
            return (New-ActionFailure -Category $Category -Message ('关闭休眠失败：' + ($out -join ' ')))
        }

        'ComponentStore' {
            if (-not $isAdmin) {
                return (New-ActionFailure -Category $Category -Message '需要管理员权限才能清理组件存储')
            }
            $out = & Dism.exe /Online /Cleanup-Image /StartComponentCleanup 2>&1
            $ok = ($out -join "`n") -match '操作成功完成|The operation completed successfully'
            $freeAfter = Get-FreeSpaceBytes
            $freed = [long]0
            if ($freeAfter -gt $freeBefore) { $freed = $freeAfter - $freeBefore }
            if (-not $ok) {
                return (New-ActionFailure -Category $Category -Message ('DISM 执行未成功：' + (($out | Select-Object -Last 3) -join ' ')))
            }
            return [pscustomobject]@{
                Id = $Category.Id; Name = $Category.Name; Risk = $Category.Risk
                Success = $true; FreedBytes = $freed
                DeletedFiles = 0; DeletedDirs = 0; SkippedCount = 0
                Denied = @(); Skipped = @(); Errors = @()
                Message = '组件存储清理完成'
            }
        }

        'ComponentStoreReset' {
            if (-not $isAdmin) {
                return (New-ActionFailure -Category $Category -Message '需要管理员权限才能执行深度清理')
            }
            $out = & Dism.exe /Online /Cleanup-Image /StartComponentCleanup /ResetBase 2>&1
            $ok = ($out -join "`n") -match '操作成功完成|The operation completed successfully'
            $freeAfter = Get-FreeSpaceBytes
            $freed = [long]0
            if ($freeAfter -gt $freeBefore) { $freed = $freeAfter - $freeBefore }
            if (-not $ok) {
                return (New-ActionFailure -Category $Category -Message ('DISM 执行未成功：' + (($out | Select-Object -Last 3) -join ' ')))
            }
            return [pscustomobject]@{
                Id = $Category.Id; Name = $Category.Name; Risk = $Category.Risk
                Success = $true; FreedBytes = $freed
                DeletedFiles = 0; DeletedDirs = 0; SkippedCount = 0
                Denied = @(); Skipped = @(); Errors = @()
                Message = '组件存储深度清理完成'
            }
        }
    }

    return $null
}

function New-ActionFailure {
    param($Category, [string]$Message)
    return [pscustomobject]@{
        Id = $Category.Id; Name = $Category.Name; Risk = $Category.Risk
        Success = $false; FreedBytes = [long]0
        DeletedFiles = 0; DeletedDirs = 0; SkippedCount = 0
        Denied = @(); Skipped = @(); Errors = @(@{ Path = $Category.Name; Reason = $Message })
        Message = $Message
    }
}

# ==============================================================================
# 风险说明文本（供界面与文档复用）
# ==============================================================================

function Get-SafetyNotice {
    return @'
【使用前请阅读】

本工具只清理"可自动重建的缓存与临时文件"，不会触碰你的文档、照片、桌面、
下载、聊天记录、游戏存档等个人资料，也不包含任何格式化、分区、磁盘初始化
或删除系统还原点的功能。

清理是不可逆操作。虽然目标是缓存类文件，但以下情况请特别注意：

1. 回收站一旦清空，其中的文件将无法通过常规方式恢复。
2. Windows.old 删除后，将无法回滚到升级前的旧版 Windows。
3. 关闭休眠会同时关闭「快速启动」，开机速度会略微变慢。
4. 组件存储深度清理（ResetBase）执行后，已安装的 Windows 更新将无法卸载。
5. 正在被程序占用的文件会被自动跳过，不会强制结束进程。
6. 浏览器只清理缓存，书签、密码、Cookie 与登录状态均保留。

建议在清理前保存好正在进行的工作。若不确定某一项的作用，请不要勾选它。
'@
}

# ==============================================================================
# 导出
# ==============================================================================

Export-ModuleMember -Function @(
    'Get-CleanerVersion',
    'Format-Size',
    'Get-FreeSpaceBytes',
    'Test-IsAdministrator',
    'Test-SafeTarget',
    'Get-ProtectedPaths',
    'Get-PathSize',
    'Clear-PathTree',
    'Invoke-CleanPaths',
    'Get-CleanCategories',
    'Resolve-CleanCategory',
    'Resolve-AllCategories',
    'Get-CategoryEstimate',
    'Invoke-CleanCategory',
    'Get-SafetyNotice'
)
