﻿#Requires -Version 5.1
<#
================================================================================
 CDiskCleaner - C 盘安全清理工具（图形界面）
================================================================================
 运行方式：双击 Start-Cleaner.bat，或
           powershell -ExecutionPolicy Bypass -File CDiskCleaner.ps1

 安全设计：
   * 只清理白名单中列出的缓存/临时目录
   * 清理前必须由用户逐个勾选并二次确认
   * 不触碰个人文档、桌面、下载、聊天记录、游戏存档
   * 正在被占用的文件自动跳过
   * 权限不足时提示用户提权，不强行操作
================================================================================
#>

param(
    # 仅供自动化测试跳过风险确认页，日常使用不要加
    [switch]$SkipConsent
)

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module (Join-Path $script:ScriptRoot 'CleanerEngine.psm1') -Force

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

# ==============================================================================
# 全局状态
# ==============================================================================
$script:IsAdmin = Test-IsAdministrator
$script:Categories = @()
$script:IsBusy = $false
$script:CancelRequested = $false
$script:ScanResults = @{}
$script:CleanResults = @()
$script:FreeBefore = [long]0
$script:FreeAfter = [long]0

$script:ColorSafe = [System.Drawing.Color]::FromArgb(22, 163, 74)
$script:ColorCaution = [System.Drawing.Color]::FromArgb(217, 119, 6)
$script:ColorHigh = [System.Drawing.Color]::FromArgb(220, 38, 38)
$script:ColorMuted = [System.Drawing.Color]::FromArgb(107, 114, 128)
$script:ColorAccent = [System.Drawing.Color]::FromArgb(37, 99, 235)

$script:RiskText = @{ 'Safe' = '安全'; 'Caution' = '谨慎'; 'High' = '高风险' }
$script:RiskColor = @{
    'Safe' = $script:ColorSafe
    'Caution' = $script:ColorCaution
    'High' = $script:ColorHigh
}

function Update-Ui {
    # 让界面在长任务中保持响应
    [System.Windows.Forms.Application]::DoEvents()
}

# ==============================================================================
# 剪贴板安全的复制函数（避免 TextBox 只读时 Ctrl+C 不生效）
# ==============================================================================
function Get-RiskSummaryLine {
    param($Category, [long]$Estimate)
    $sizeText = if ($Estimate -lt 0) { '运行后确定' } else { Format-Size -Bytes $Estimate }
    return ('[{0}] {1}  —  {2}' -f $script:RiskText[$Category.Risk], $Category.Name, $sizeText)
}

# ==============================================================================
# 主窗体
# ==============================================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = 'CDiskCleaner — C 盘安全清理工具'
$form.Size = New-Object System.Drawing.Size(1080, 760)
$form.MinimumSize = New-Object System.Drawing.Size(900, 620)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(249, 250, 251)
$form.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)

$statusStrip = New-Object System.Windows.Forms.StatusStrip
$statusStrip.BackColor = [System.Drawing.Color]::White
$lblStatus = New-Object System.Windows.Forms.ToolStripStatusLabel
$lblStatus.Text = '就绪'
$lblStatus.Spring = $true
$lblStatus.TextAlign = 'MiddleLeft'
$pbar = New-Object System.Windows.Forms.ToolStripProgressBar
$pbar.Width = 220
$pbar.Visible = $false
[void]$statusStrip.Items.Add($lblStatus)
[void]$statusStrip.Items.Add($pbar)

$layout = New-Object System.Windows.Forms.TableLayoutPanel
$layout.Dock = 'Fill'
$layout.ColumnCount = 1
$layout.RowCount = 6
$layout.Padding = New-Object System.Windows.Forms.Padding(14, 10, 14, 6)
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 58)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 46)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 96)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 58)))
$form.Controls.Add($layout)
$form.Controls.Add($statusStrip)

# ---------------------------------------------------------------- 标题栏
$pnlHeader = New-Object System.Windows.Forms.Panel
$pnlHeader.Dock = 'Fill'
$pnlHeader.BackColor = [System.Drawing.Color]::White
$pnlHeader.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = 'C 盘安全清理工具'
$lblTitle.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 15, [System.Drawing.FontStyle]::Bold)
$lblTitle.ForeColor = [System.Drawing.Color]::FromArgb(17, 24, 39)
$lblTitle.AutoSize = $true
$lblTitle.Location = New-Object System.Drawing.Point(14, 8)
$pnlHeader.Controls.Add($lblTitle)

$lblSub = New-Object System.Windows.Forms.Label
$lblSub.Text = '只清理可自动重建的缓存与临时文件，不触碰个人资料'
$lblSub.ForeColor = $script:ColorMuted
$lblSub.AutoSize = $true
$lblSub.Location = New-Object System.Drawing.Point(16, 34)
$pnlHeader.Controls.Add($lblSub)

$lblAdmin = New-Object System.Windows.Forms.Label
$lblAdmin.AutoSize = $false
$lblAdmin.Size = New-Object System.Drawing.Size(150, 24)
$lblAdmin.TextAlign = 'MiddleCenter'
$lblAdmin.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9, [System.Drawing.FontStyle]::Bold)
$lblAdmin.Anchor = 'Top,Right'
$pnlHeader.Controls.Add($lblAdmin)
$pnlHeader.Add_Resize({
    $lblAdmin.Location = New-Object System.Drawing.Point(($pnlHeader.Width - 164), 12)
})
[void]$layout.Controls.Add($pnlHeader, 0, 0)

# ---------------------------------------------------------------- 风险提示条
$pnlRisk = New-Object System.Windows.Forms.Panel
$pnlRisk.Dock = 'Fill'
$pnlRisk.BackColor = [System.Drawing.Color]::FromArgb(255, 251, 235)
$pnlRisk.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)

$lblRisk = New-Object System.Windows.Forms.Label
$lblRisk.Text = '⚠ 清理操作不可撤销。请先阅读风险说明，逐项确认后再执行。'
$lblRisk.ForeColor = [System.Drawing.Color]::FromArgb(146, 64, 14)
$lblRisk.AutoSize = $true
$lblRisk.Location = New-Object System.Drawing.Point(12, 15)
$pnlRisk.Controls.Add($lblRisk)

$btnNotice = New-Object System.Windows.Forms.LinkLabel
$btnNotice.Text = '查看完整风险说明'
$btnNotice.AutoSize = $true
$btnNotice.Anchor = 'Top,Right'
$btnNotice.LinkColor = [System.Drawing.Color]::FromArgb(146, 64, 14)
$pnlRisk.Controls.Add($btnNotice)
$pnlRisk.Add_Resize({
    $btnNotice.Location = New-Object System.Drawing.Point(($pnlRisk.Width - 150), 15)
})
[void]$layout.Controls.Add($pnlRisk, 0, 1)

# ---------------------------------------------------------------- 工具条
$pnlTools = New-Object System.Windows.Forms.Panel
$pnlTools.Dock = 'Fill'
$pnlTools.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)

function New-ToolButton {
    param([string]$Text, [int]$X, [int]$W = 100)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Size = New-Object System.Drawing.Size($W, 32)
    $b.Location = New-Object System.Drawing.Point($X, 6)
    $b.FlatStyle = 'System'
    $b.BackColor = [System.Drawing.Color]::White
    return $b
}

$btnRecommended = New-ToolButton -Text '推荐选择' -X 0 -W 96
$btnNone = New-ToolButton -Text '全部取消' -X 102 -W 96
$btnRescan = New-ToolButton -Text '重新扫描' -X 204 -W 96
$btnCancel = New-ToolButton -Text '停止扫描' -X 306 -W 96
$btnCancel.Enabled = $false
$btnElevate = New-ToolButton -Text '以管理员身份重启' -X 408 -W 148
$btnElevate.BackColor = [System.Drawing.Color]::FromArgb(239, 246, 255)

foreach ($b in @($btnRecommended, $btnNone, $btnRescan, $btnCancel, $btnElevate)) {
    [void]$pnlTools.Controls.Add($b)
}
[void]$layout.Controls.Add($pnlTools, 0, 2)

# ---------------------------------------------------------------- 清理项目列表
$lv = New-Object System.Windows.Forms.ListView
$lv.Dock = 'Fill'
$lv.View = 'Details'
$lv.CheckBoxes = $true
$lv.FullRowSelect = $true
$lv.HideSelection = $false
$lv.ShowGroups = $true
$lv.ShowItemToolTips = $true
$lv.BorderStyle = 'FixedSingle'
$lv.BackColor = [System.Drawing.Color]::White
$lv.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
$lv.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
[void]$lv.Columns.Add('清理项目', 250)
[void]$lv.Columns.Add('分类', 90)
[void]$lv.Columns.Add('风险', 66)
[void]$lv.Columns.Add('预计释放', 105)
[void]$lv.Columns.Add('说明', 420)
$lv.GridLines = $false
[void]$layout.Controls.Add($lv, 0, 3)

# ---------------------------------------------------------------- 详情
$txtDetail = New-Object System.Windows.Forms.TextBox
$txtDetail.Dock = 'Fill'
$txtDetail.Multiline = $true
$txtDetail.ReadOnly = $true
$txtDetail.ScrollBars = 'Vertical'
$txtDetail.BackColor = [System.Drawing.Color]::White
$txtDetail.BorderStyle = 'FixedSingle'
$txtDetail.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 8.5)
$txtDetail.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
$txtDetail.Text = '选中上方任意项目，这里会显示它的具体作用与将被清理的路径。'
[void]$layout.Controls.Add($txtDetail, 0, 4)

# ---------------------------------------------------------------- 底部操作区
$pnlBottom = New-Object System.Windows.Forms.Panel
$pnlBottom.Dock = 'Fill'

$lblSel = New-Object System.Windows.Forms.Label
$lblSel.Text = '已选 0 项 · 预计释放 0 B'
$lblSel.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 11)
$lblSel.ForeColor = [System.Drawing.Color]::FromArgb(17, 24, 39)
$lblSel.AutoSize = $true
$lblSel.Location = New-Object System.Drawing.Point(2, 16)
$pnlBottom.Controls.Add($lblSel)

$btnClean = New-Object System.Windows.Forms.Button
$btnClean.Text = '开始清理'
$btnClean.Size = New-Object System.Drawing.Size(170, 42)
$btnClean.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 11, [System.Drawing.FontStyle]::Bold)
$btnClean.BackColor = $script:ColorAccent
$btnClean.ForeColor = [System.Drawing.Color]::White
$btnClean.FlatStyle = 'Flat'
$btnClean.FlatAppearance.BorderSize = 0
$btnClean.Anchor = 'Top,Right'
$pnlBottom.Controls.Add($btnClean)
$pnlBottom.Add_Resize({
    $btnClean.Location = New-Object System.Drawing.Point(($pnlBottom.Width - 178), 8)
})
[void]$layout.Controls.Add($pnlBottom, 0, 5)

# ==============================================================================
# 行为逻辑
# ==============================================================================

function Show-NoticeDialog {
    param([string]$Title, [string]$Content)
    $d = New-Object System.Windows.Forms.Form
    $d.Text = $Title
    $d.Size = New-Object System.Drawing.Size(720, 560)
    $d.StartPosition = 'CenterParent'
    $d.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
    $d.BackColor = [System.Drawing.Color]::White

    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true
    $tb.ReadOnly = $true
    $tb.ScrollBars = 'Vertical'
    $tb.Dock = 'Fill'
    $tb.BorderStyle = 'None'
    $tb.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 10)
    $tb.Text = $Content
    $tb.Padding = New-Object System.Windows.Forms.Padding(16)
    $d.Controls.Add($tb)

    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Bottom'
    $p.Height = 56
    $b = New-Object System.Windows.Forms.Button
    $b.Text = '关闭'
    $b.Size = New-Object System.Drawing.Size(110, 34)
    $b.Anchor = 'Top,Right'
    $b.Location = New-Object System.Drawing.Point(580, 11)
    $b.Add_Click({ $d.Close() })
    $p.Controls.Add($b)
    $p.Add_Resize({ $b.Location = New-Object System.Drawing.Point(($p.Width - 126), 11) })
    $d.Controls.Add($p)
    $d.AcceptButton = $b
    # 只读 TextBox 获得焦点会自动全选，这里取消选中
    $tb.TabStop = $false
    $d.Add_Shown({ $tb.SelectionStart = 0; $tb.SelectionLength = 0 })
    [void]$d.ShowDialog($form)
}

function Show-ConsentDialog {
    # 首次启动必须同意的风险确认
    $d = New-Object System.Windows.Forms.Form
    $d.Text = '使用前请阅读 — 风险提示'
    $d.Size = New-Object System.Drawing.Size(760, 570)
    $d.StartPosition = 'CenterScreen'
    $d.FormBorderStyle = 'FixedDialog'
    $d.MaximizeBox = $false
    $d.MinimizeBox = $false
    $d.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
    $d.BackColor = [System.Drawing.Color]::White

    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text = 'C 盘安全清理工具 — 风险提示与使用说明'
    $lblHead.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 13, [System.Drawing.FontStyle]::Bold)
    $lblHead.AutoSize = $true
    $lblHead.Location = New-Object System.Drawing.Point(18, 16)
    $d.Controls.Add($lblHead)

    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true
    $tb.ReadOnly = $true
    $tb.ScrollBars = 'Vertical'
    $tb.BorderStyle = 'FixedSingle'
    $tb.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9.5)
    $tb.Size = New-Object System.Drawing.Size(706, 336)
    $tb.Location = New-Object System.Drawing.Point(18, 56)
    $tb.Text = (Get-SafetyNotice)
    $tb.BackColor = [System.Drawing.Color]::FromArgb(249, 250, 251)
    $tb.TabStop = $false
    $d.Controls.Add($tb)

    $chk = New-Object System.Windows.Forms.CheckBox
    $chk.Text = '我已阅读并理解上述风险，知晓清理操作不可撤销'
    $chk.AutoSize = $true
    $chk.Location = New-Object System.Drawing.Point(20, 400)
    $d.Controls.Add($chk)

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = '同意并继续'
    $btnOk.Size = New-Object System.Drawing.Size(150, 38)
    $btnOk.Location = New-Object System.Drawing.Point(578, 440)
    $btnOk.BackColor = $script:ColorAccent
    $btnOk.ForeColor = [System.Drawing.Color]::White
    $btnOk.FlatStyle = 'Flat'
    $btnOk.FlatAppearance.BorderSize = 0
    $btnOk.Enabled = $false
    $d.Controls.Add($btnOk)

    $btnNo = New-Object System.Windows.Forms.Button
    $btnNo.Text = '退出'
    $btnNo.Size = New-Object System.Drawing.Size(110, 38)
    $btnNo.Location = New-Object System.Drawing.Point(456, 440)
    $d.Controls.Add($btnNo)

    # 只读 TextBox 获得焦点会自动全选，看起来像整块蓝底，这里取消选中
    $d.Add_Shown({
        $tb.SelectionStart = 0
        $tb.SelectionLength = 0
    })

    $chk.Add_CheckedChanged({ $btnOk.Enabled = $chk.Checked })
    $btnOk.Add_Click({ $d.Tag = 'ok'; $d.Close() })
    $btnNo.Add_Click({ $d.Tag = 'no'; $d.Close() })
    $d.AcceptButton = $btnOk

    [void]$d.ShowDialog()
    return ($d.Tag -eq 'ok')
}

function Set-AdminBadge {
    if ($script:IsAdmin) {
        $lblAdmin.Text = '✔ 管理员模式'
        $lblAdmin.BackColor = [System.Drawing.Color]::FromArgb(220, 252, 231)
        $lblAdmin.ForeColor = [System.Drawing.Color]::FromArgb(22, 101, 52)
        $btnElevate.Enabled = $false
    } else {
        $lblAdmin.Text = '普通用户模式'
        $lblAdmin.BackColor = [System.Drawing.Color]::FromArgb(254, 243, 199)
        $lblAdmin.ForeColor = [System.Drawing.Color]::FromArgb(146, 64, 14)
        $btnElevate.Enabled = $true
    }
}

function Test-CategoryAvailable {
    param($Category)
    if (-not [string]::IsNullOrWhiteSpace($Category.Action)) {
        if ($Category.Action -eq 'HibernateOff') {
            $hf = Join-Path $env:SystemDrive 'hiberfil.sys'
            try { return [System.IO.File]::Exists($hf) } catch { return $false }
        }
        return $true
    }
    return ($Category.ResolvedPaths.Count -gt 0)
}

function Update-SelectionSummary {
    $count = 0
    $total = [long]0
    $unknown = $false
    foreach ($item in $lv.Items) {
        if (-not $item.Checked) { continue }
        $count++
        $est = [long]$item.Tag.Estimate
        if ($est -lt 0) { $unknown = $true } else { $total += $est }
    }
    $text = ('已选 {0} 项 · 预计释放 {1}' -f $count, (Format-Size -Bytes $total))
    if ($unknown) { $text += '（部分项目清理后确定）' }
    $lblSel.Text = $text
    $btnClean.Enabled = ($count -gt 0) -and (-not $script:IsBusy)
}

function Update-DetailPane {
    if ($lv.SelectedItems.Count -eq 0) {
        $txtDetail.Text = '选中上方任意项目，这里会显示它的具体作用与将被清理的路径。'
        return
    }
    $cat = $lv.SelectedItems[0].Tag
    $lines = New-Object System.Collections.ArrayList
    [void]$lines.Add(('【{0}】  风险等级：{1}  预计释放：{2}' -f `
        $cat.Name, $script:RiskText[$cat.Risk], $(if ($cat.Estimate -lt 0) { '运行后确定' } else { Format-Size -Bytes $cat.Estimate })))
    [void]$lines.Add('')
    [void]$lines.Add($cat.Description)
    [void]$lines.Add('')
    if (-not [string]::IsNullOrWhiteSpace($cat.Action)) {
        [void]$lines.Add('执行方式：' + $cat.ActionDetail + '（需调用系统命令，会产生独立确认）')
    }
    if ($cat.ResolvedPaths.Count -gt 0) {
        [void]$lines.Add(('将被清理的路径（共 {0} 处）：' -f $cat.ResolvedPaths.Count))
        foreach ($p in $cat.ResolvedPaths) { [void]$lines.Add('  · ' + $p) }
    } elseif ([string]::IsNullOrWhiteSpace($cat.Action)) {
        [void]$lines.Add('本机未检测到该项目的目录。')
    }
    $txtDetail.Text = ($lines -join "`r`n")
}

function Build-ListView {
    $lv.BeginUpdate()
    $lv.Items.Clear()
    $lv.Groups.Clear()

    $groupOrder = @('临时文件', '浏览器', '显卡缓存', '系统', '应用缓存', '开发缓存')
    $groups = @{}
    foreach ($g in $groupOrder) {
        $grp = New-Object System.Windows.Forms.ListViewGroup($g)
        $lv.Groups.Add($grp)
        $groups[$g] = $grp
    }

    $recommended = @()
    foreach ($cat in $script:Categories) {
        $available = Test-CategoryAvailable -Category $cat
        $est = [long]$cat.Estimate

        $item = New-Object System.Windows.Forms.ListViewItem($cat.Name)
        [void]$item.SubItems.Add($cat.Group)
        [void]$item.SubItems.Add($script:RiskText[$cat.Risk])
        [void]$item.SubItems.Add($(if ($est -lt 0) { '运行后确定' } else { Format-Size -Bytes $est }))
        [void]$item.SubItems.Add($cat.Description)
        $item.Tag = $cat
        $item.ForeColor = $script:RiskColor[$cat.Risk]
        $item.ToolTipText = $cat.Description

        if ($available) {
            if ($groups.ContainsKey($cat.Group)) { $item.Group = $groups[$cat.Group] }
            [void]$lv.Items.Add($item)
            if ($cat.Risk -eq 'Safe') { $recommended += $item }
        } else {
            $item.ForeColor = [System.Drawing.Color]::FromArgb(180, 180, 180)
            $item.ToolTipText = '本机未检测到该项目，已隐藏'
        }
    }

    $lv.EndUpdate()

    # 默认只勾选"安全"级别的项目
    foreach ($item in $recommended) { $item.Checked = $true }
    $lv.Tag = $recommended
}

function Start-Scan {
    if ($script:IsBusy) { return }
    $script:IsBusy = $true
    $script:CancelRequested = $false
    $btnCancel.Enabled = $true
    $btnRescan.Enabled = $false
    $btnClean.Enabled = $false
    $pbar.Visible = $true

    try {
        $lblStatus.Text = '正在扫描可清理的目录…'
        Update-Ui

        $resolved = @(Resolve-AllCategories)
        $script:Categories = @()
        $total = @($resolved | Where-Object { Test-CategoryAvailable -Category $_ }).Count
        $i = 0

        foreach ($cat in $resolved) {
            if ($script:CancelRequested) { break }
            $i++
            $pbar.Maximum = [Math]::Max($total, 1)
            $pbar.Value = [Math]::Min($i, $pbar.Maximum)
            $lblStatus.Text = ('正在统计（{0}/{1}）：{2}' -f $i, $total, $cat.Name)
            Update-Ui

            $est = [long]-1
            if (Test-CategoryAvailable -Category $cat) {
                try { $est = [long](Get-CategoryEstimate -Category $cat) } catch { $est = [long]-1 }
            }
            $cat | Add-Member -NotePropertyName 'Estimate' -NotePropertyValue $est -Force
            $script:Categories += $cat
        }

        Build-ListView
        Update-SelectionSummary
        Update-DetailPane

        if ($script:CancelRequested) {
            $lblStatus.Text = '扫描已取消'
        } else {
            $detected = @($lv.Items).Count
            $lblStatus.Text = ('扫描完成：检测到 {0} 个可清理项目，可用空间 {1}' -f $detected, (Format-Size -Bytes (Get-FreeSpaceBytes)))
        }
    } catch {
        $lblStatus.Text = '扫描出错：' + $_.Exception.Message
    } finally {
        $script:IsBusy = $false
        $pbar.Visible = $false
        $btnCancel.Enabled = $false
        $btnRescan.Enabled = $true
        Update-SelectionSummary
    }
}

function Show-ConfirmDialog {
    param([object[]]$SelectedCategories, [long]$EstimateTotal)
    $d = New-Object System.Windows.Forms.Form
    $d.Text = '确认清理'
    $d.Size = New-Object System.Drawing.Size(760, 580)
    $d.StartPosition = 'CenterParent'
    $d.FormBorderStyle = 'FixedDialog'
    $d.MaximizeBox = $false
    $d.MinimizeBox = $false
    $d.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
    $d.BackColor = [System.Drawing.Color]::White

    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text = ('即将清理 {0} 个项目，预计释放 {1}' -f $SelectedCategories.Count, (Format-Size -Bytes $EstimateTotal))
    $lblHead.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 12, [System.Drawing.FontStyle]::Bold)
    $lblHead.AutoSize = $true
    $lblHead.Location = New-Object System.Drawing.Point(18, 16)
    $d.Controls.Add($lblHead)

    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true
    $tb.ReadOnly = $true
    $tb.ScrollBars = 'Vertical'
    $tb.BorderStyle = 'FixedSingle'
    $tb.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9.5)
    $tb.Size = New-Object System.Drawing.Size(706, 396)
    $tb.Location = New-Object System.Drawing.Point(18, 56)
    $tb.BackColor = [System.Drawing.Color]::FromArgb(249, 250, 251)

    $lines = New-Object System.Collections.ArrayList
    [void]$lines.Add('本次将要清理的项目：')
    [void]$lines.Add('')
    foreach ($c in $SelectedCategories) {
        $sizeText = if ([long]$c.Estimate -lt 0) { '运行后确定' } else { Format-Size -Bytes ([long]$c.Estimate) }
        [void]$lines.Add(('  ● [{0}] {1} —— {2}' -f $script:RiskText[$c.Risk], $c.Name, $sizeText))
    }
    [void]$lines.Add('')
    [void]$lines.Add('清理规则：')
    [void]$lines.Add('  · 只删除上述目录内部的内容，目录本身保留')
    [void]$lines.Add('  · 正在被程序占用的文件会自动跳过，不会强制结束进程')
    [void]$lines.Add('  · 不会删除文档、桌面、下载、照片、聊天记录等个人资料')
    [void]$lines.Add('')

    $highRisk = @($SelectedCategories | Where-Object { $_.Risk -eq 'High' })
    $caution = @($SelectedCategories | Where-Object { $_.Risk -eq 'Caution' })
    if ($highRisk.Count -gt 0) {
        [void]$lines.Add('⚠ 你选择了高风险项目：')
        foreach ($h in $highRisk) { [void]$lines.Add('    - ' + $h.Name + '：' + $h.Description) }
        [void]$lines.Add('')
    }
    $adminNeeded = @($SelectedCategories | Where-Object { $_.Admin })
    if (-not $script:IsAdmin -and $adminNeeded.Count -gt 0) {
        [void]$lines.Add(('⚠ 其中 {0} 个项目需要管理员权限，当前为普通用户模式，这些项目可能无法完成。' -f $adminNeeded.Count))
        [void]$lines.Add('   建议先点击「以管理员身份重启」再来清理。')
        [void]$lines.Add('')
    }
    [void]$lines.Add('清理开始后可以随时关闭窗口，但已被删除的缓存无法恢复。')

    $tb.Text = ($lines -join "`r`n")
    $d.Controls.Add($tb)

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = '确认清理'
    $btnOk.Size = New-Object System.Drawing.Size(150, 38)
    $btnOk.Location = New-Object System.Drawing.Point(578, 470)
    $btnOk.BackColor = $script:ColorAccent
    $btnOk.ForeColor = [System.Drawing.Color]::White
    $btnOk.FlatStyle = 'Flat'
    $btnOk.FlatAppearance.BorderSize = 0
    $d.Controls.Add($btnOk)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = '取消'
    $btnCancel.Size = New-Object System.Drawing.Size(110, 38)
    $btnCancel.Location = New-Object System.Drawing.Point(456, 470)
    $d.Controls.Add($btnCancel)

    $btnOk.Add_Click({ $d.Tag = 'ok'; $d.Close() })
    $btnCancel.Add_Click({ $d.Tag = 'cancel'; $d.Close() })
    $d.AcceptButton = $btnOk
    $d.CancelButton = $btnCancel

    # 只读 TextBox 获得焦点时会自动全选，看起来像整块蓝底，这里取消选中
    $tb.TabStop = $false
    $d.Add_Shown({
        $tb.SelectionStart = 0
        $tb.SelectionLength = 0
        $tb.ScrollToCaret()
    })

    [void]$d.ShowDialog($form)
    return ($d.Tag -eq 'ok')
}

function Invoke-Cleanup {
    $selected = New-Object System.Collections.ArrayList
    $estimateTotal = [long]0
    foreach ($item in $lv.Items) {
        if ($item.Checked) {
            [void]$selected.Add($item.Tag)
            if ([long]$item.Tag.Estimate -gt 0) { $estimateTotal += [long]$item.Tag.Estimate }
        }
    }
    if ($selected.Count -eq 0) { return }

    if (-not (Show-ConfirmDialog -SelectedCategories @($selected) -EstimateTotal $estimateTotal)) {
        $lblStatus.Text = '已取消清理'
        return
    }

    $script:IsBusy = $true
    $btnClean.Enabled = $false
    $btnRescan.Enabled = $false
    $btnRecommended.Enabled = $false
    $btnNone.Enabled = $false
    $pbar.Visible = $true
    $pbar.Maximum = $selected.Count
    $pbar.Value = 0

    $script:FreeBefore = Get-FreeSpaceBytes
    $script:CleanResults = @()

    $i = 0
    try {
        foreach ($cat in $selected) {
            $i++
            $pbar.Value = [Math]::Min($i, $pbar.Maximum)
            $lblStatus.Text = ('正在清理（{0}/{1}）：{2}' -f $i, $selected.Count, $cat.Name)
            Update-Ui

            try {
                $r = Invoke-CleanCategory -Category $cat
            } catch {
                $r = [pscustomobject]@{
                    Id = $cat.Id; Name = $cat.Name; Risk = $cat.Risk
                    Success = $false; FreedBytes = [long]0
                    DeletedFiles = 0; DeletedDirs = 0; SkippedCount = 0
                    Denied = @(); Skipped = @(); Errors = @(@{ Path = $cat.Name; Reason = $_.Exception.Message })
                    Message = $_.Exception.Message
                }
            }
            $script:CleanResults += $r

            $lblStatus.Text = ('已完成：{0}（{1}）' -f $cat.Name, (Format-Size -Bytes $r.FreedBytes))
            Update-Ui
        }
    } finally {
        $script:FreeAfter = Get-FreeSpaceBytes
        $script:IsBusy = $false
        $pbar.Visible = $false
        $btnRescan.Enabled = $true
        $btnRecommended.Enabled = $true
        $btnNone.Enabled = $true
        Update-SelectionSummary
    }

    Show-ResultDialog
}

function Show-ResultDialog {
    $freedTotal = [long]0
    $skippedTotal = 0
    $deniedTotal = 0
    foreach ($r in $script:CleanResults) {
        $freedTotal += [long]$r.FreedBytes
        $skippedTotal += [int]$r.SkippedCount
        $deniedTotal += @($r.Denied).Count
    }
    $actualDelta = $script:FreeAfter - $script:FreeBefore
    if ($actualDelta -lt 0) { $actualDelta = 0 }

    $d = New-Object System.Windows.Forms.Form
    $d.Text = '清理完成'
    $d.Size = New-Object System.Drawing.Size(820, 620)
    $d.StartPosition = 'CenterParent'
    $d.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
    $d.BackColor = [System.Drawing.Color]::White

    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text = ('✔ 清理完成，共释放 {0}' -f (Format-Size -Bytes $freedTotal))
    $lblHead.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 15, [System.Drawing.FontStyle]::Bold)
    $lblHead.ForeColor = $script:ColorSafe
    $lblHead.AutoSize = $true
    $lblHead.Location = New-Object System.Drawing.Point(18, 14)
    $d.Controls.Add($lblHead)

    $lblSub = New-Object System.Windows.Forms.Label
    $lblSub.Text = ('清理前可用 {0}  →  清理后可用 {1}（实际增加 {2}）' -f `
        (Format-Size -Bytes $script:FreeBefore), (Format-Size -Bytes $script:FreeAfter), (Format-Size -Bytes $actualDelta))
    $lblSub.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9.5)
    $lblSub.ForeColor = $script:ColorMuted
    $lblSub.AutoSize = $true
    $lblSub.Location = New-Object System.Drawing.Point(20, 52)
    $d.Controls.Add($lblSub)

    $rstats = New-Object System.Windows.Forms.Label
    $rstats.Text = ('跳过 {0} 个占用文件 · 权限不足 {1} 项' -f $skippedTotal, $deniedTotal)
    $rstats.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
    $rstats.ForeColor = $(if (($skippedTotal + $deniedTotal) -gt 0) { $script:ColorCaution } else { $script:ColorMuted })
    $rstats.AutoSize = $true
    $rstats.Location = New-Object System.Drawing.Point(20, 76)
    $d.Controls.Add($rstats)

    $rlv = New-Object System.Windows.Forms.ListView
    $rlv.View = 'Details'
    $rlv.FullRowSelect = $true
    $rlv.GridLines = $false
    $rlv.BorderStyle = 'FixedSingle'
    $rlv.Location = New-Object System.Drawing.Point(18, 106)
    $rlv.Size = New-Object System.Drawing.Size(766, 380)
    $rlv.Anchor = 'Top,Left,Right,Bottom'
    [void]$rlv.Columns.Add('项目', 260)
    [void]$rlv.Columns.Add('结果', 90)
    [void]$rlv.Columns.Add('释放', 110)
    [void]$rlv.Columns.Add('删除文件', 90)
    [void]$rlv.Columns.Add('跳过', 70)
    [void]$rlv.Columns.Add('备注', 140)

    foreach ($r in $script:CleanResults) {
        $it = New-Object System.Windows.Forms.ListViewItem($r.Name)
        [void]$it.SubItems.Add($(if ($r.Success) { '成功' } else { '失败' }))
        [void]$it.SubItems.Add((Format-Size -Bytes ([long]$r.FreedBytes)))
        [void]$it.SubItems.Add([string]$r.DeletedFiles)
        [void]$it.SubItems.Add([string]$r.SkippedCount)
        [void]$it.SubItems.Add([string]$r.Message)
        if (-not $r.Success) { $it.ForeColor = $script:ColorHigh }
        [void]$rlv.Items.Add($it)
    }
    # 合计行
    $itTotal = New-Object System.Windows.Forms.ListViewItem('合计')
    [void]$itTotal.SubItems.Add('')
    [void]$itTotal.SubItems.Add((Format-Size -Bytes $freedTotal))
    [void]$itTotal.SubItems.Add('')
    [void]$itTotal.SubItems.Add([string]$skippedTotal)
    [void]$itTotal.SubItems.Add('')
    $itTotal.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9, [System.Drawing.FontStyle]::Bold)
    [void]$rlv.Items.Add($itTotal)
    $d.Controls.Add($rlv)

    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Text = '保存报告'
    $btnSave.Size = New-Object System.Drawing.Size(130, 36)
    $btnSave.Anchor = 'Bottom,Right'
    $btnSave.Location = New-Object System.Drawing.Point(654, 528)
    $d.Controls.Add($btnSave)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = '关闭'
    $btnClose.Size = New-Object System.Drawing.Size(110, 36)
    $btnClose.Anchor = 'Bottom,Right'
    $btnClose.Location = New-Object System.Drawing.Point(530, 528)
    $d.Controls.Add($btnClose)

    $btnSave.Add_Click({
        $sfd = New-Object System.Windows.Forms.SaveFileDialog
        $sfd.Filter = '文本报告 (*.txt)|*.txt|CSV 表格 (*.csv)|*.csv'
        $sfd.FileName = ('C盘清理报告_{0}.txt' -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
        if ($sfd.ShowDialog() -eq 'OK') {
            $sb = New-Object System.Text.StringBuilder
            [void]$sb.AppendLine('CDiskCleaner 清理报告')
            [void]$sb.AppendLine(('生成时间：' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
            [void]$sb.AppendLine(('管理员模式：' + $script:IsAdmin))
            [void]$sb.AppendLine('')
            [void]$sb.AppendLine(('清理前可用空间：' + (Format-Size -Bytes $script:FreeBefore)))
            [void]$sb.AppendLine(('清理后可用空间：' + (Format-Size -Bytes $script:FreeAfter)))
            [void]$sb.AppendLine(('实际释放：' + (Format-Size -Bytes $actualDelta)))
            [void]$sb.AppendLine(('统计释放：' + (Format-Size -Bytes $freedTotal)))
            [void]$sb.AppendLine(('跳过占用文件：' + $skippedTotal + ' 个'))
            [void]$sb.AppendLine(('权限不足项：' + $deniedTotal + ' 个'))
            [void]$sb.AppendLine('')
            [void]$sb.AppendLine('明细：')
            foreach ($r in $script:CleanResults) {
                [void]$sb.AppendLine(('  {0} | {1} | 释放 {2} | 删除 {3} 文件 | 跳过 {4} | {5}' -f `
                    $r.Name, $(if ($r.Success) { '成功' } else { '失败' }), (Format-Size -Bytes ([long]$r.FreedBytes)), $r.DeletedFiles, $r.SkippedCount, $r.Message))
                foreach ($dn in @($r.Denied)) {
                    [void]$sb.AppendLine(('      权限不足：' + $dn.Path + ' — ' + $dn.Reason))
                }
            }
            try {
                [System.IO.File]::WriteAllText($sfd.FileName, $sb.ToString(), (New-Object System.Text.UTF8Encoding($true)))
                [void][System.Windows.Forms.MessageBox]::Show('报告已保存：' + "`n" + $sfd.FileName, '保存成功')
            } catch {
                [void][System.Windows.Forms.MessageBox]::Show('保存失败：' + $_.Exception.Message, '错误')
            }
        }
    })
    $btnClose.Add_Click({ $d.Close() })

    # 权限不足时引导提权
    if ($deniedTotal -gt 0 -and -not $script:IsAdmin) {
        $ans = [System.Windows.Forms.MessageBox]::Show(
            ('有 {0} 个条目因权限不足被跳过。是否以管理员身份重新启动，以便下次清理这些系统目录？' -f $deniedTotal),
            '需要管理员权限',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question)
        if ($ans -eq 'Yes') {
            $d.Close()
            Restart-Elevated
            return
        }
    }

    [void]$d.ShowDialog($form)
}

function Restart-Elevated {
    try {
        $scriptPath = $PSCommandPath
        if ([string]::IsNullOrWhiteSpace($scriptPath)) { $scriptPath = $MyInvocation.MyCommand.Path }
        $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $scriptPath + '"'))
        Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs | Out-Null
        $form.Close()
    } catch {
        [void][System.Windows.Forms.MessageBox]::Show(
            '提权失败：' + $_.Exception.Message + "`n（若在 UAC 弹窗中点了「否」，可稍后重试）",
            '无法获取管理员权限')
    }
}

# ---------------------------------------------------------------- 事件绑定
$btnRecommended.Add_Click({
    foreach ($item in $lv.Items) { $item.Checked = ($item.Tag.Risk -eq 'Safe') }
    Update-SelectionSummary
})
$btnNone.Add_Click({
    foreach ($item in $lv.Items) { $item.Checked = $false }
    Update-SelectionSummary
})
$btnRescan.Add_Click({ Start-Scan })
$btnCancel.Add_Click({ $script:CancelRequested = $true; $lblStatus.Text = '正在停止…' })
$btnElevate.Add_Click({ Restart-Elevated })
$btnClean.Add_Click({ Invoke-Cleanup })
$btnNotice.Add_Click({ Show-NoticeDialog -Title '风险说明与使用须知' -Content (Get-SafetyNotice) })
$lv.Add_ItemChecked({ Update-SelectionSummary })
$lv.Add_SelectedIndexChanged({ Update-DetailPane })

$form.Add_Shown({
    Set-AdminBadge
    if (-not $SkipConsent) {
        if (-not (Show-ConsentDialog)) { $form.Close(); return }
    }
    Start-Scan
})

$form.Add_FormClosing({
    if ($script:IsBusy) {
        $ans = [System.Windows.Forms.MessageBox]::Show(
            '清理或扫描正在进行中，确定要退出吗？' + "`n" + '（已删除的缓存无法恢复）',
            '确认退出',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($ans -eq 'No') { $_.Cancel = $true }
    }
})

$form.Add_Resize({
    $lv.Columns[4].Width = [Math]::Max(200, $lv.Width - 930)
})

[void]$form.ShowDialog()
