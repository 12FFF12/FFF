@echo off
chcp 65001 >nul 2>&1
setlocal
title CDiskCleaner - C盘安全清理工具

set "SCRIPT=%~dp0CDiskCleaner.ps1"

if not exist "%SCRIPT%" (
    echo.
    echo   [错误] 未找到 CDiskCleaner.ps1
    echo          请确认 Start-Cleaner.bat、CDiskCleaner.ps1、CleanerEngine.psm1
    echo          三个文件在同一个文件夹里。
    echo.
    pause
    exit /b 1
)

echo ================================================================
echo                  CDiskCleaner - C盘安全清理工具
echo ================================================================
echo    · 只清理可自动重建的缓存与临时文件
echo    · 不删除文档、照片、桌面、下载、聊天记录等个人资料
echo    · 不格式化、不分区、不改动系统设置
echo    · 清理前先列出清单，需要你逐项确认才会执行
echo ================================================================
echo.
echo   正在启动图形界面，请稍候...
echo   如果窗口没有出现，请检查本窗口下方的错误信息。
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
    echo.
    echo   [提示] 程序退出码：%RC%
    echo          请把上面的错误信息反馈给工具提供者。
    pause
)

endlocal
